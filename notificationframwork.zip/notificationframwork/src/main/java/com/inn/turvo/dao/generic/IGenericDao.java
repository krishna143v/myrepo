package com.inn.turvo.dao.generic;

import java.util.List;
import org.apache.cxf.jaxrs.ext.search.SearchContext;
import org.json.JSONObject;

public interface IGenericDao<Pk, Entity> extends IBaseDao<Pk, Entity>{

	List<Entity> findByExample(Entity refEntity, String[] excludeProperty);
	

	 List<Entity> search(SearchContext ctx ,Integer maxLimit,Integer minLimit );
	 
	
	 List<Entity> search(SearchContext ctx ,Integer maxLimit,Integer minLimit,String orderby,String orderType );
	 
	 List<JSONObject> findAudit(Pk pk);
	 }
