package com.inn.turvo.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;


@Entity
@Audited
@Table(name = "channel")
public class UserDetails {

	@Id
	@GeneratedValue(strategy=javax.persistence.GenerationType.TABLE,generator = "DocTagGenerator")
	private Integer id;
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id", columnDefinition="INT ")
	private Users userId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id", columnDefinition="INT ")
	private Users channelId;
	
	
}
