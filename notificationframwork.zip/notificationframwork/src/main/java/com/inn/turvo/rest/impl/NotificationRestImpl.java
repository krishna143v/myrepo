package com.inn.turvo.rest.impl;

import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;


/**
 * The Class DocumentRestImpl.
 */
@Path("Document")
@Produces("application/json")
@Consumes("application/json")
@Service("DocumentRestImpl")
public class NotificationRestImpl {

	/** The Constant logger. */
	private static final Logger logger=LoggerFactory.getLogger(NotificationRestImpl.class);

	
	
	
}
