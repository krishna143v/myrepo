package com.inn.app23march1.dao.generic;

import java.util.List;

import com.inn.app23march1.utils.QueryObject;


public interface IBaseDao <Pk, Entity> {
	
	Entity create(Entity anEntity) ;
	
	Entity update(Entity anEntity) ;
	
	void delete(Entity anEntity) ;
	
	void deleteByPk(Pk entityPk) ;
	
	boolean contains(Entity anEntity);
	
	
	int count(QueryObject queryObject);
	
	Entity findByPk(Pk entityPk) ;
	
	List<Entity> findAll() ;
	
	List<Entity> find(QueryObject queryObject) ;
}
