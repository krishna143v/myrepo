package com.inn.turvo.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.validator.constraints.Length;


@Entity
@Audited
@Table(name = "users")
public class Users {

	@Id
	@GeneratedValue(strategy=javax.persistence.GenerationType.TABLE,generator = "DocTagGenerator")
	private Integer id;
	
	@Basic
	@Column(name="name",unique=true,length=250)
	@Length(max=250)
	private String name;
	
	@Basic
	@Column(name="email",length=250)
	@Length(max=250)
	private String email;
	
	@Basic
	@Column(name="mobilenumber",length=250)
	@Length(max=250)
	private String mobilenumber;
	
	
	
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

}
